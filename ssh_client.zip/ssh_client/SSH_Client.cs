﻿using System;
using System.IO;
using System.Runtime.InteropServices;

using Renci.SshNet;



///
///     SSH接続用COMコンポーネント
///
namespace ssh_client
{
    [Guid( SSH_Client.ClassId )]

    /// <summary>
    /// SSH_Client
    /// </summary>
    public class SSH_Client
    {
        /// <summary>
        /// 
        /// </summary>
        public const string ClassId = "5E2CCAFF-BB7C-45C3-B4E9-D7761AF614A2";



        /// <summary>
        /// 
        /// </summary>
        /// <param name="srv"></param>
        /// <param name="u_id"></param>
        /// <param name="u_pass"></param>
        /// <param name="cmd"></param>
        /// <param name="res_std"></param>
        /// <param name="res_err"></param>
        /// <returns></returns>
        public bool ssh_exec1( string srv , string u_id , string u_pass , string cmd , ref string res_std , ref string res_err )
        {
            try {

                var client = new SshClient( srv , u_id , u_pass );

                client.Connect();                                       //  接続
                var command = client.RunCommand( cmd );                 //  コマンド実行

                res_std = command.Result;                               //  標準出力
                res_std = res_std.Substring( 0 , res_std.Length - 1 );  //  行末の改行コードを削除

                res_err = command.Error;                                //  エラー出力
                res_std = res_std.Substring( 0 , res_std.Length - 1 );  //  行末の改行コードを削除

                client.Disconnect();
                return ( true );

            }
            catch {
                return ( false );
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="srv"></param>
        /// <param name="u_id"></param>
        /// <param name="u_pphase"></param>
        /// <param name="pkeyfile"></param>
        /// <param name="cmd"></param>
        /// <param name="res_std"></param>
        /// <param name="res_err"></param>
        /// <returns></returns>
        public bool ssh_exec2( string srv , string u_id , string u_pphase , string pkeyfile , string cmd , ref string res_std , ref string res_err )
        {
            try {
                var key = new PrivateKeyFile( pkeyfile , u_pphase );
                var connection = new PrivateKeyConnectionInfo( srv , u_id , key );
                var client = new SshClient( connection );

                client.Connect();                                       //  接続
                var command = client.RunCommand( cmd );                 //  コマンド実行

                res_std = command.Result;                               //  標準出力
                res_std = res_std.Substring( 0 , res_std.Length - 1 );  //  行末の改行コードを削除

                res_err = command.Error;                                //  エラー出力
                res_std = res_std.Substring( 0 , res_std.Length - 1 );  //  行末の改行コードを削除

                client.Disconnect();
                return ( true );

            }catch{
                return ( false );
            }
        }

        
        /// <summary>
        ///   認証(ssh)
        /// </summary>
        /// <param name="srv"></param>
        /// <param name="u_id"></param>
        /// <param name="u_pass"></param>
        /// <param name="pkeyfile"></param>
        /// <returns></returns>
        public SshClient ssh_com( string srv , string u_id , string u_pass , string pkeyfile = null )
        {
            try {
                if( String.IsNullOrEmpty( pkeyfile ) ) {
                    return new SshClient( srv , u_id , u_pass );

                } else {
                    var key = new PrivateKeyFile( pkeyfile , u_pass );
                    var connection = new PrivateKeyConnectionInfo( srv , u_id , key );
                    return new SshClient( connection );
                }
            }
            catch {
                throw;
            }
        }

        
        /// <summary>
        /// パスワード認証の時は、pkeyfileを""にする
        /// </summary>
        /// <param name="srv"></param>
        /// <param name="u_id"></param>
        /// <param name="u_pphase"></param>
        /// <param name="pkeyfile"></param>
        /// <param name="cmd"></param>
        /// <param name="res_std"></param>
        /// <param name="res_err"></param>
        /// <returns></returns>
        public bool ssh_exec( string srv , string u_id , string u_pphase , string pkeyfile , string cmd , ref string res_std , ref string res_err )
        {
            try {
                var client = ssh_com( srv , u_id , u_pphase , pkeyfile );

                client.Connect();                                       //  接続
                var command = client.RunCommand( cmd );                 //  コマンド実行

                res_std = command.Result;                               //  標準出力
                res_std = res_std.Substring( 0 , res_std.Length - 1 );  //  行末の改行コードを削除

                res_err = command.Error;                                //  エラー出力
                res_std = res_std.Substring( 0 , res_std.Length - 1 );  //  行末の改行コードを削除

                client.Disconnect();
                return ( true );

            }
            catch {
                return ( false );
            }
        }


        /// <summary>
        /// 認証(sftp)
        /// </summary>
        /// <param name="srv"></param>
        /// <param name="u_id"></param>
        /// <param name="u_pass"></param>
        /// <param name="pkeyfile"></param>
        /// <returns></returns>
        public SftpClient sftp_com( string srv , string u_id , string u_pass , string pkeyfile = null )
        {
            try {
                if( String.IsNullOrEmpty( pkeyfile ) ) {
                    return new SftpClient( srv , u_id , u_pass );

                } else {
                    var key = new PrivateKeyFile( pkeyfile , u_pass );
                    var connection = new PrivateKeyConnectionInfo( srv , u_id , key );
                    return new SftpClient( connection );
                }
            }
            catch {
                throw;
            }
        }


        /// <summary>
        /// パスワード認証の時は、pkeyfileを""にする
        /// </summary>
        /// <param name="srv"></param>
        /// <param name="u_id"></param>
        /// <param name="u_pass"></param>
        /// <param name="pkeyfile"></param>
        /// <param name="rmt_dir"></param>
        /// <param name="rmt_fname"></param>
        /// <param name="lcl_fname"></param>
        /// <returns></returns>
        public bool sftp_put( string srv , string u_id , string u_pass , string pkeyfile , string rmt_dir , string rmt_fname , string lcl_fname )
        {
            try {
                var sftp = sftp_com( srv , u_id , u_pass , pkeyfile );  //  認証
                
                sftp.Connect();                                         //  接続

                var local_file = File.OpenRead( lcl_fname )  ;          //  ローカルのファイルを開く

                sftp.ChangeDirectory( rmt_dir );                        //  サーバ側のディレクトリーを変更
                sftp.UploadFile( local_file , rmt_fname );              //  ファイルをPUT

                local_file.Close();

                sftp.Disconnect();
                return ( true );

            }catch{
                return ( false );
            }
        }


        /// <summary>
        /// パスワード認証の時は、pkeyfileを""にする
        /// </summary>
        /// <param name="srv"></param>
        /// <param name="u_id"></param>
        /// <param name="u_pass"></param>
        /// <param name="pkeyfile"></param>
        /// <param name="rmt_dir"></param>
        /// <param name="rmt_fname"></param>
        /// <param name="lcl_fname"></param>
        /// <returns></returns>
        public bool sftp_get( string srv , string u_id , string u_pass , string pkeyfile , string rmt_dir , string rmt_fname , string lcl_fname )
        {
            try {
                var sftp = sftp_com( srv , u_id , u_pass , pkeyfile );  //  認証

                sftp.Connect();                                         //  接続

                var local_file = File.OpenWrite( lcl_fname );           //  ローカルのファイルを開く：上書き

                sftp.ChangeDirectory( rmt_dir );                        //  サーバ側のディレクトリーを変更
                sftp.DownloadFile( rmt_fname , local_file );            //  ファイルをGET
                
                sftp.Disconnect();
                local_file.Close();
                return ( true );

            }catch{
                return ( false );
            }
        }

    
    }
}
