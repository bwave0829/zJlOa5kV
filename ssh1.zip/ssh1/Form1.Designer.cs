﻿namespace ssh1
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose( bool disposing )
        {
            if( disposing && ( components != null ) ) {
                components.Dispose();
            }
            base.Dispose( disposing );
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txt_srv = new System.Windows.Forms.TextBox();
            this.lbl_srv = new System.Windows.Forms.Label();
            this.lbl_uid = new System.Windows.Forms.Label();
            this.lbl_pass = new System.Windows.Forms.Label();
            this.txt_uid = new System.Windows.Forms.TextBox();
            this.txt_passwd = new System.Windows.Forms.TextBox();
            this.lbl_cmd = new System.Windows.Forms.Label();
            this.txt_cmd = new System.Windows.Forms.TextBox();
            this.txt_res1 = new System.Windows.Forms.TextBox();
            this.lbl_res = new System.Windows.Forms.Label();
            this.txt_res2 = new System.Windows.Forms.TextBox();
            this.btn_exec = new System.Windows.Forms.Button();
            this.btn_downld = new System.Windows.Forms.Button();
            this.btn_upld = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_upld2 = new System.Windows.Forms.Button();
            this.btn_downld2 = new System.Windows.Forms.Button();
            this.btn_exec2 = new System.Windows.Forms.Button();
            this.txt_reserr2 = new System.Windows.Forms.TextBox();
            this.txt_resstd2 = new System.Windows.Forms.TextBox();
            this.txt_cmd2 = new System.Windows.Forms.TextBox();
            this.txt_passphase = new System.Windows.Forms.TextBox();
            this.txt_uid2 = new System.Windows.Forms.TextBox();
            this.txt_srv2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_pkey = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txt_pkey);
            this.tabPage2.Controls.Add(this.btn_upld2);
            this.tabPage2.Controls.Add(this.btn_downld2);
            this.tabPage2.Controls.Add(this.btn_exec2);
            this.tabPage2.Controls.Add(this.txt_reserr2);
            this.tabPage2.Controls.Add(this.txt_resstd2);
            this.tabPage2.Controls.Add(this.txt_cmd2);
            this.tabPage2.Controls.Add(this.txt_passphase);
            this.tabPage2.Controls.Add(this.txt_uid2);
            this.tabPage2.Controls.Add(this.txt_srv2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(634, 408);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "秘密鍵";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btn_upld);
            this.tabPage1.Controls.Add(this.btn_downld);
            this.tabPage1.Controls.Add(this.btn_exec);
            this.tabPage1.Controls.Add(this.txt_res2);
            this.tabPage1.Controls.Add(this.txt_res1);
            this.tabPage1.Controls.Add(this.txt_cmd);
            this.tabPage1.Controls.Add(this.txt_passwd);
            this.tabPage1.Controls.Add(this.txt_uid);
            this.tabPage1.Controls.Add(this.txt_srv);
            this.tabPage1.Controls.Add(this.lbl_res);
            this.tabPage1.Controls.Add(this.lbl_cmd);
            this.tabPage1.Controls.Add(this.lbl_pass);
            this.tabPage1.Controls.Add(this.lbl_uid);
            this.tabPage1.Controls.Add(this.lbl_srv);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(634, 408);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "パスワード";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txt_srv
            // 
            this.txt_srv.Location = new System.Drawing.Point(87, 16);
            this.txt_srv.Name = "txt_srv";
            this.txt_srv.Size = new System.Drawing.Size(100, 19);
            this.txt_srv.TabIndex = 12;
            // 
            // lbl_srv
            // 
            this.lbl_srv.AutoSize = true;
            this.lbl_srv.Location = new System.Drawing.Point(19, 20);
            this.lbl_srv.Name = "lbl_srv";
            this.lbl_srv.Size = new System.Drawing.Size(38, 12);
            this.lbl_srv.TabIndex = 13;
            this.lbl_srv.Text = "Server";
            // 
            // lbl_uid
            // 
            this.lbl_uid.AutoSize = true;
            this.lbl_uid.Location = new System.Drawing.Point(19, 54);
            this.lbl_uid.Name = "lbl_uid";
            this.lbl_uid.Size = new System.Drawing.Size(16, 12);
            this.lbl_uid.TabIndex = 14;
            this.lbl_uid.Text = "ID";
            // 
            // lbl_pass
            // 
            this.lbl_pass.AutoSize = true;
            this.lbl_pass.Location = new System.Drawing.Point(19, 92);
            this.lbl_pass.Name = "lbl_pass";
            this.lbl_pass.Size = new System.Drawing.Size(44, 12);
            this.lbl_pass.TabIndex = 15;
            this.lbl_pass.Text = "Passwd";
            // 
            // txt_uid
            // 
            this.txt_uid.Location = new System.Drawing.Point(87, 51);
            this.txt_uid.Name = "txt_uid";
            this.txt_uid.Size = new System.Drawing.Size(100, 19);
            this.txt_uid.TabIndex = 16;
            // 
            // txt_passwd
            // 
            this.txt_passwd.Location = new System.Drawing.Point(87, 89);
            this.txt_passwd.Name = "txt_passwd";
            this.txt_passwd.PasswordChar = '*';
            this.txt_passwd.Size = new System.Drawing.Size(100, 19);
            this.txt_passwd.TabIndex = 17;
            // 
            // lbl_cmd
            // 
            this.lbl_cmd.AutoSize = true;
            this.lbl_cmd.Location = new System.Drawing.Point(21, 126);
            this.lbl_cmd.Name = "lbl_cmd";
            this.lbl_cmd.Size = new System.Drawing.Size(55, 12);
            this.lbl_cmd.TabIndex = 18;
            this.lbl_cmd.Text = "Command";
            // 
            // txt_cmd
            // 
            this.txt_cmd.Location = new System.Drawing.Point(87, 126);
            this.txt_cmd.Name = "txt_cmd";
            this.txt_cmd.PasswordChar = '*';
            this.txt_cmd.Size = new System.Drawing.Size(184, 19);
            this.txt_cmd.TabIndex = 19;
            // 
            // txt_res1
            // 
            this.txt_res1.Location = new System.Drawing.Point(9, 169);
            this.txt_res1.Multiline = true;
            this.txt_res1.Name = "txt_res1";
            this.txt_res1.Size = new System.Drawing.Size(619, 94);
            this.txt_res1.TabIndex = 20;
            // 
            // lbl_res
            // 
            this.lbl_res.AutoSize = true;
            this.lbl_res.Location = new System.Drawing.Point(-157, 91);
            this.lbl_res.Name = "lbl_res";
            this.lbl_res.Size = new System.Drawing.Size(38, 12);
            this.lbl_res.TabIndex = 21;
            this.lbl_res.Text = "Result";
            // 
            // txt_res2
            // 
            this.txt_res2.Location = new System.Drawing.Point(9, 286);
            this.txt_res2.Multiline = true;
            this.txt_res2.Name = "txt_res2";
            this.txt_res2.Size = new System.Drawing.Size(619, 94);
            this.txt_res2.TabIndex = 22;
            // 
            // btn_exec
            // 
            this.btn_exec.Location = new System.Drawing.Point(251, 20);
            this.btn_exec.Name = "btn_exec";
            this.btn_exec.Size = new System.Drawing.Size(53, 25);
            this.btn_exec.TabIndex = 23;
            this.btn_exec.Text = "exec";
            this.btn_exec.UseVisualStyleBackColor = true;
            // 
            // btn_downld
            // 
            this.btn_downld.Location = new System.Drawing.Point(326, 20);
            this.btn_downld.Name = "btn_downld";
            this.btn_downld.Size = new System.Drawing.Size(74, 25);
            this.btn_downld.TabIndex = 24;
            this.btn_downld.Text = "download";
            this.btn_downld.UseVisualStyleBackColor = true;
            // 
            // btn_upld
            // 
            this.btn_upld.Location = new System.Drawing.Point(413, 20);
            this.btn_upld.Name = "btn_upld";
            this.btn_upld.Size = new System.Drawing.Size(74, 25);
            this.btn_upld.TabIndex = 25;
            this.btn_upld.Text = "upload";
            this.btn_upld.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(35, 50);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(642, 434);
            this.tabControl1.TabIndex = 13;
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(604, 30);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(53, 25);
            this.btn_exit.TabIndex = 24;
            this.btn_exit.Text = "exit";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // btn_upld2
            // 
            this.btn_upld2.Location = new System.Drawing.Point(412, 26);
            this.btn_upld2.Name = "btn_upld2";
            this.btn_upld2.Size = new System.Drawing.Size(74, 25);
            this.btn_upld2.TabIndex = 38;
            this.btn_upld2.Text = "upload";
            this.btn_upld2.UseVisualStyleBackColor = true;
            // 
            // btn_downld2
            // 
            this.btn_downld2.Location = new System.Drawing.Point(325, 26);
            this.btn_downld2.Name = "btn_downld2";
            this.btn_downld2.Size = new System.Drawing.Size(74, 25);
            this.btn_downld2.TabIndex = 37;
            this.btn_downld2.Text = "download";
            this.btn_downld2.UseVisualStyleBackColor = true;
            // 
            // btn_exec2
            // 
            this.btn_exec2.Location = new System.Drawing.Point(250, 26);
            this.btn_exec2.Name = "btn_exec2";
            this.btn_exec2.Size = new System.Drawing.Size(53, 25);
            this.btn_exec2.TabIndex = 36;
            this.btn_exec2.Text = "exec";
            this.btn_exec2.UseVisualStyleBackColor = true;
            this.btn_exec2.Click += new System.EventHandler(this.btn_exec2_Click);
            // 
            // txt_reserr2
            // 
            this.txt_reserr2.Location = new System.Drawing.Point(8, 292);
            this.txt_reserr2.Multiline = true;
            this.txt_reserr2.Name = "txt_reserr2";
            this.txt_reserr2.Size = new System.Drawing.Size(619, 94);
            this.txt_reserr2.TabIndex = 35;
            // 
            // txt_resstd2
            // 
            this.txt_resstd2.Location = new System.Drawing.Point(8, 175);
            this.txt_resstd2.Multiline = true;
            this.txt_resstd2.Name = "txt_resstd2";
            this.txt_resstd2.Size = new System.Drawing.Size(619, 94);
            this.txt_resstd2.TabIndex = 34;
            // 
            // txt_cmd2
            // 
            this.txt_cmd2.Location = new System.Drawing.Point(86, 132);
            this.txt_cmd2.Name = "txt_cmd2";
            this.txt_cmd2.PasswordChar = '*';
            this.txt_cmd2.Size = new System.Drawing.Size(184, 19);
            this.txt_cmd2.TabIndex = 33;
            this.txt_cmd2.Text = "ls";
            // 
            // txt_passphase
            // 
            this.txt_passphase.Location = new System.Drawing.Point(86, 95);
            this.txt_passphase.Name = "txt_passphase";
            this.txt_passphase.PasswordChar = '*';
            this.txt_passphase.Size = new System.Drawing.Size(100, 19);
            this.txt_passphase.TabIndex = 31;
            // 
            // txt_uid2
            // 
            this.txt_uid2.Location = new System.Drawing.Point(86, 57);
            this.txt_uid2.Name = "txt_uid2";
            this.txt_uid2.Size = new System.Drawing.Size(100, 19);
            this.txt_uid2.TabIndex = 30;
            this.txt_uid2.Text = "srv-wld";
            // 
            // txt_srv2
            // 
            this.txt_srv2.Location = new System.Drawing.Point(86, 22);
            this.txt_srv2.Name = "txt_srv2";
            this.txt_srv2.Size = new System.Drawing.Size(100, 19);
            this.txt_srv2.TabIndex = 26;
            this.txt_srv2.Text = "172.17.1.20";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 132);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 12);
            this.label1.TabIndex = 32;
            this.label1.Text = "Command";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 12);
            this.label2.TabIndex = 29;
            this.label2.Text = "PassPhase";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 12);
            this.label3.TabIndex = 28;
            this.label3.Text = "ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 12);
            this.label4.TabIndex = 27;
            this.label4.Text = "Server";
            // 
            // txt_pkey
            // 
            this.txt_pkey.Location = new System.Drawing.Point(273, 98);
            this.txt_pkey.Name = "txt_pkey";
            this.txt_pkey.Size = new System.Drawing.Size(269, 19);
            this.txt_pkey.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(206, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 12);
            this.label5.TabIndex = 40;
            this.label5.Text = "PrivateKey";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 496);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btn_upld;
        private System.Windows.Forms.Button btn_downld;
        private System.Windows.Forms.Button btn_exec;
        private System.Windows.Forms.TextBox txt_res2;
        private System.Windows.Forms.TextBox txt_res1;
        private System.Windows.Forms.TextBox txt_cmd;
        private System.Windows.Forms.TextBox txt_passwd;
        private System.Windows.Forms.TextBox txt_uid;
        private System.Windows.Forms.TextBox txt_srv;
        private System.Windows.Forms.Label lbl_res;
        private System.Windows.Forms.Label lbl_cmd;
        private System.Windows.Forms.Label lbl_pass;
        private System.Windows.Forms.Label lbl_uid;
        private System.Windows.Forms.Label lbl_srv;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_pkey;
        private System.Windows.Forms.Button btn_upld2;
        private System.Windows.Forms.Button btn_downld2;
        private System.Windows.Forms.Button btn_exec2;
        private System.Windows.Forms.TextBox txt_reserr2;
        private System.Windows.Forms.TextBox txt_resstd2;
        private System.Windows.Forms.TextBox txt_cmd2;
        private System.Windows.Forms.TextBox txt_passphase;
        private System.Windows.Forms.TextBox txt_uid2;
        private System.Windows.Forms.TextBox txt_srv2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;

    }
}

