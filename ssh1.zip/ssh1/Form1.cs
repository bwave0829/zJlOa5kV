﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;

using Renci.SshNet;
using Renci.SshNet.Sftp;


//
//      「SshNet」試験モジュール
//
namespace ssh1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //  サーバで、コマンドを実行して、結果を取得する
        private void button1_Click( object sender , EventArgs e )
        {
            btn_exec.Enabled = false;
            var client = new SshClient( txt_srv.Text , txt_uid.Text , txt_passwd.Text );
            client.Connect();

            var command = client.RunCommand( txt_cmd.Text );

            txt_res1.Text = command.Result;     //  標準出力

            txt_res2.Text = command.Error;      //  エラー出力

            client.Disconnect();

            btn_exec.Enabled = true;

        }



        //  ファイルのGET（download）
        private void button2_Click( object sender , EventArgs e )
        {
            using( var sftp = new SftpClient( "www1" , "root" , "root" ) ) {
                sftp.Connect();
                string downloadedFileName = "zshrc.txt";
                string remote_fname = ".zshrc";

                using( var local_file = File.OpenWrite( downloadedFileName ) ) {    // 上書き
                    try {
                        sftp.DownloadFile( remote_fname , local_file );
                    }
                    catch( Exception ex ) {
                        System.Console.WriteLine( ex.Message );
                    }
                }

                sftp.Disconnect();
            }
        }


        //  ファイルのPUT（upload）
        private void button3_Click( object sender , EventArgs e )
        {
            using( var sftp = new SftpClient( "www1" , "root" , "root" ) ) {
                sftp.Connect();
                string local_fname = "zshrc.txt";
                string remote_fname = "zshrc_tmp.txt";

                using( var local_file = File.OpenRead( local_fname ) ) {
                    try {
                        sftp.ChangeDirectory( "/var/tmp" );
                        sftp.UploadFile( local_file , remote_fname );
                    }
                    catch( Exception ex ) {
                        System.Console.WriteLine( ex.Message );
                    }
                } 

                sftp.Disconnect();
            }

        }

        private void btn_exit_Click( object sender , EventArgs e )
        {
            this.Close();
        }



        //
        //  秘密鍵を使った、SSH接続（コマンドを実行して、結果を取得する）
        //      秘密鍵は、OpenSSH形式（putty形式はNG)
        //
        private void btn_exec2_Click( object sender , EventArgs e )
        {
            btn_exec2.Enabled = false;


            var key = new PrivateKeyFile( txt_pkey.Text , txt_passphase.Text );
            var connection = new PrivateKeyConnectionInfo( txt_srv2.Text , txt_uid2.Text , key ) ;
            var client = new SshClient( connection ) ;
            client.Connect();

            var command = client.RunCommand( txt_cmd2.Text );

            txt_resstd2.Text = command.Result;     //  標準出力

            txt_reserr2.Text = command.Error;      //  エラー出力

            client.Disconnect();

            btn_exec2.Enabled = true;

        }
    }
}
