﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;


//
//  プロジェクトの「参照」「COM」において、Microsoft Excel 16.0 Object Libraryを追加すること
//



namespace extool {
    class ExTool
    {
        static Application ExcelApp = new Application();
        static Workbook WorkBook = null;
        static String Wkbook_Name;
        static ArrayList Confs = new ArrayList();

        //  コンストラクタ
        public ExTool() {
            //エクセルを非表示
            ExcelApp.Visible = false;
        }

        public ExTool(String wkbook_name) {
            //エクセルを非表示
            ExcelApp.Visible = false;

            //エクセルファイルのオープン
            ExcelOpen(wkbook_name);
        }

        public void ExcelOpen(String wkbook_name) {
            //エクセルファイルのオープン
            ExcelClose();
            Wkbook_Name = wkbook_name;
            WorkBook = ExcelApp.Workbooks.Open(Wkbook_Name);
        }

        public void ExcelClose() {
            //  ワークブックを閉じる
            if (null != WorkBook) {
                WorkBook.Close();
            }
        }


        //  デストラクター
        ~ExTool() {
            Debug.WriteLine("called デストラクター");

            ExcelClose();
            
            if (null != ExcelApp) {
                ExcelApp.Quit();    //  エクセルを閉じる
            }
            // アプリケーションのオブジェクトの解放
            System.Runtime.InteropServices.Marshal.ReleaseComObject(WorkBook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(ExcelApp);
            GC.Collect();

            //  プログラム終了（コンソール）
            //Environment.Exit(0);
        }


        //  ワークブックを保存する
        public void Workbook_Save() {
            WorkBook.Save();
        }

        
        //  指定した条件に一致するシートの一覧(ArrayList)を返す
        public ArrayList GetSheets(String nameRex) {
            var sheet_count = WorkBook.Sheets.Count;
            ArrayList ret_list = new ArrayList();

            for (int cnt = 1; cnt <= sheet_count; cnt++) {
                if (Regex.IsMatch(WorkBook.Sheets[cnt].Name, nameRex)){
                    ret_list.Add(WorkBook.Sheets[cnt].Name);
                }
            }
            return(ret_list);
        }


        //  指定されたブック／シート／範囲に値を設定する
        public void SetCell(String wksheet_name , String range_name, String setVal) {
            Worksheet worksheet = WorkBook.Worksheets[wksheet_name];
            Range range = worksheet.Range[range_name];
            range.Value= setVal;
        }


        //  指定されたブック／シート／範囲に値を設定する：メイン
        public void SetCellmain(String wksheet_name, String range_name, String set_val, Boolean is_set) {
            var sheet_list = GetSheets(wksheet_name);
            foreach (String mysheet in sheet_list) {
                if (is_set) {
                    SetCell(mysheet, range_name, set_val);
                }
                Console.WriteLine("{0},{1},{2},{3},{4}", Path.GetDirectoryName(Wkbook_Name),Path.GetFileName(Wkbook_Name), mysheet, range_name, set_val);
            }
            if (is_set) {
                //  ワークブックを保存
                Workbook_Save();
            }
        }


        //  指定されたブック／シート／範囲から値を取得する
        public String GetCell(String wksheet_name, String range_name) {
            Worksheet worksheet = WorkBook.Worksheets[wksheet_name];
            Range range = worksheet.Range[range_name];
            return(range.Value);
        }

        //  指定されたブック／シート／範囲から値を取得する：メイン
        public void GetCellmain(String wksheet_name, String range_name) {
            Debug.WriteLine("getCells");

            var sheet_list = GetSheets(wksheet_name);
            foreach (String mysheet in sheet_list) {
                var myval = GetCell(mysheet, range_name);
                Console.WriteLine("{0},{1},{2},{3},{4}", Path.GetDirectoryName(Wkbook_Name), Path.GetFileName(Wkbook_Name), mysheet, range_name, myval);
            }
        }

        //  指定されたファイルを
        public static void  ConfRead(String filename, String encoding = "Shift_JIS") {
            string line = "";

            using (StreamReader sr = new StreamReader(
                 filename, Encoding.GetEncoding(encoding))) {

                while ((line = sr.ReadLine()) != null) {
                    Confs.Add(line);
                }
            }
        }

        static void usage() {
            Console.WriteLine("extool cmd workbook worksheet range [value]");
            Console.WriteLine("ex)extool get workbook worksheet range");
            Console.WriteLine("ex)extool set workbook worksheet range abcdef");
            Console.WriteLine("ex)extool test workbook worksheet range abcdef");

            Console.WriteLine("ex)extool getall dir worksheet range");
            Console.WriteLine("ex)extool setall dir worksheet range abcdef");
            Console.WriteLine("ex)extool testall dir worksheet range abcdef");

            Console.WriteLine("ex)extool batget workbook batfile");
            Console.WriteLine("ex)extool batset workbook batfile\n");

            Console.WriteLine("ex)extool batsetall dir batfile");
            Console.WriteLine("ex)extool batgetall dir batfile\n");
        }


        static void Main(string[] args)
        {
            //  引数の数をチェック
            if( !(args.Length > 2 && args.Length <6 )) {
                usage();
                Environment.Exit(0);
            }

            Dictionary<String, int> cmd_argc = new Dictionary<String,int>() {
                {"get",4 },{"set",5 },{"test",5 },
                {"getall",4 },{"setall",5 },{"testall",5 },
                {"batget",3 },{"batset",3 },
                {"batgetall",3 },{"batsetall",3 }
            };

            //  コマンドのチェック
            if (! ( cmd_argc.ContainsKey(args[0]) && cmd_argc[args[0]] == args.Length)) {
                usage();
                Environment.Exit(0);
            }

            var cmd = args[0];
            var wkbook_name = args[1];
            String wksheet_name = args[2];
            String set_val = null;
            String conf_file = null;
            String range_name = null;
            String search_dir = null;

            if (Array.IndexOf(new String[] { "set", "test", "setall", "testall" }, args[0]) != -1) {
                set_val = args[4];
            }
            if (Array.IndexOf(new String[] { "batset", "batget", "batgetall", "batsetall" }, args[0]) != -1) {
                conf_file = args[2];
            } else {
                range_name = args[3];
            }
            if (Array.IndexOf(new String[] { "getall", "setall", "testall", "batgetall", "batsetall" }, args[0]) != -1) {
                search_dir = Path.GetFullPath(args[1]);
            }

            if (cmd.Equals("get")) {
                //  条件を満たすシートから、指定された範囲の値を取得する
                //  出力形式：ブック名/シート名/範囲名/値
                Debug.WriteLine("get");

                ExTool extool = new ExTool(wkbook_name);
                extool.GetCellmain(wksheet_name, range_name);

            } else if (cmd.Equals("getall")) {
                //  指定されたディレクトリー配下のブックを検索し、
                //  条件を満たすシートから、指定された範囲の値を取得する
                //  出力形式：ブック名/シート名/範囲名/値
                Debug.WriteLine("getall");

                string[] files = Directory.GetFiles(search_dir, "*.xls*", SearchOption.AllDirectories);
                ExTool extool = new ExTool();
                foreach (var mywkbook in files) {
                    extool.ExcelOpen(mywkbook);
                    extool.GetCellmain(wksheet_name, range_name);
                }

            } else if (cmd.Equals("set")) {
                //  条件を満たすシートに対し、指定された範囲へ値を設定する
                //  出力形式：ブック名/シート名/範囲名/値
                Debug.WriteLine("set");

                ExTool extool = new ExTool(wkbook_name);
                extool.SetCellmain(wksheet_name, range_name, set_val, true);

            } else if (cmd.Equals("setall")) {
                //  指定されたディレクトリー配下のブックを検索し、
                //  条件を満たすシートに対し、指定された範囲へ値を設定する
                //  出力形式：ブック名/シート名/範囲名/値
                Debug.WriteLine("setall");

                string[] files = Directory.GetFiles(search_dir, "*.xls*", SearchOption.AllDirectories);
                ExTool extool = new ExTool();
                foreach (var mywkbook in files) {
                    extool.ExcelOpen(mywkbook);
                    extool.SetCellmain(wksheet_name, range_name, set_val, true);
                }

            } else if (cmd.Equals("test")) {
                //  setの動作確認（書き込みは実施しない）
                Debug.WriteLine("Test : setCells");

                ExTool extool = new ExTool(wkbook_name);
                extool.SetCellmain(wksheet_name, range_name, set_val, false);

            } else if (cmd.Equals("testall")) {
                //  setallの動作確認（書き込みは実施しない）
                Debug.WriteLine("Test : setallCells");

                string[] files = Directory.GetFiles(search_dir, "*.xls*", SearchOption.AllDirectories);
                ExTool extool = new ExTool();
                foreach (var mywkbook in files) {
                    extool.ExcelOpen(mywkbook);
                    extool.SetCellmain(wksheet_name, range_name, set_val, false);
                }

            } else if (cmd.Equals("batget")) {
                //  bat for get
                Debug.WriteLine("batget");

                ExTool extool = new ExTool(wkbook_name);
                ConfRead(conf_file);
                foreach (var conf in Confs) {
                    if (!conf.ToString().Substring(0,1).Equals("#")) {
                        var paras = conf.ToString().Split(new Char[] { ',' });
                        if (paras.Length == 2) {
                            extool.GetCellmain(paras[0], paras[1]);
                        }
                    }
                }
            } else if (cmd.Equals("testall")) {
                //  setallの動作確認（書き込みは実施しない）
                Debug.WriteLine("Test : setall");

                string[] files = Directory.GetFiles(search_dir, "*.xls*", SearchOption.AllDirectories);
                ExTool extool = new ExTool();
                foreach (var mywkbook in files) {
                    extool.ExcelOpen(mywkbook);
                    extool.SetCellmain(wksheet_name, range_name, set_val, false);
                }
            } else if (cmd.Equals("batgetall")) {
                //  bat for getall
                Debug.WriteLine("batgetall");

                string[] files = Directory.GetFiles(search_dir, "*.xls*", SearchOption.AllDirectories);
                ConfRead(conf_file);
                ExTool extool = new ExTool();
                foreach (var mywkbook in files) {
                    extool.ExcelOpen(mywkbook);
                    foreach (var conf in Confs) {
                        if (conf.ToString().Substring(0, 1).Equals("#")) continue;
                        var paras = conf.ToString().Split(new Char[] { ',' });
                        if (paras.Length == 2) {
                            extool.GetCellmain(paras[0], paras[1]);
                        }
                    }
                }
            } else if (cmd.Equals("batset")) {
                //  bat for set
                Debug.WriteLine("batset");

                ExTool extool = new ExTool(wkbook_name);
                ConfRead(conf_file);
                foreach (var conf in Confs) {
                    if (conf.ToString().Substring(0, 1).Equals("#")) continue;
                    var paras = conf.ToString().Split(new Char[] { ',' });
                    if (paras.Length == 3) {
                        extool.SetCellmain(paras[0], paras[1], paras[2], true);
                    }
                }
            } else if (cmd.Equals("batsetall")) {
                //  bat for set
                Debug.WriteLine("batsetall");

                string[] files = Directory.GetFiles(search_dir, "*.xls*", SearchOption.AllDirectories);
                ConfRead(conf_file);
                ExTool extool = new ExTool();
                foreach (var mywkbook in files) {
                    extool.ExcelOpen(mywkbook);
                    foreach (var conf in Confs) {
                        if (conf.ToString().Substring(0, 1).Equals("#")) continue;
                        var paras = conf.ToString().Split(new Char[] { ',' });
                        if (paras.Length == 3) {
                            extool.SetCellmain(paras[0], paras[1], paras[2], true);
                        }
                    }
                }
            } else {
                Console.WriteLine("Illegal cmd {0}", cmd);
            }

#if DEBUG
            //  キー入力待ち
            Console.WriteLine("Hit Ret Key");
            ConsoleKeyInfo cki = Console.ReadKey();
#endif
        }
    }
}
